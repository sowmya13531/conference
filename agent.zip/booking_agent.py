"""
Conference Room Booking Multi-Agent System
Using AWS Strands Agents SDK and Bedrock
"""

import json
import boto3
import logging
from datetime import datetime, timedelta
from typing import Any, Dict, Optional
from dataclasses import dataclass, asdict
import uuid

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# AWS Clients
bedrock_agent_runtime = boto3.client('bedrock-agent-runtime', region_name='us-east-1')
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
bedrock = boto3.client('bedrock-runtime', region_name='us-east-1')

# DynamoDB Tables
EMPLOYEES_TABLE = dynamodb.Table('Employees')
ROOMS_TABLE = dynamodb.Table('ConferenceRooms')
BOOKINGS_TABLE = dynamodb.Table('Bookings')
ROOM_FEATURES_TABLE = dynamodb.Table('RoomFeatures')
ACCESS_LEVELS_TABLE = dynamodb.Table('AccessLevels')


@dataclass
class BookingRequest:
    """Data class for booking requests"""
    employee_id: str
    room_id: str
    start_time: str  # ISO format
    end_time: str    # ISO format
    attendee_count: int
    meeting_title: str


class ToolExecutor:
    """Executes all booking system tools"""
    
    @staticmethod
    def verify_employee_access(employee_id: str, room_id: str) -> Dict[str, Any]:
        """
        TOOL 1: Verify if employee has access permissions for the room
        Returns employee data and access level
        """
        try:
            # Get employee info
            emp_response = EMPLOYEES_TABLE.get_item(Key={'EmployeeID': employee_id})
            if 'Item' not in emp_response:
                return {
                    'success': False,
                    'error': f'Employee {employee_id} not found',
                    'access_granted': False
                }
            
            employee = emp_response['Item']
            access_level = employee.get('AccessLevel', 'BASIC')
            
            # Check access level requirements for room
            room_response = ROOMS_TABLE.get_item(Key={'RoomID': room_id})
            if 'Item' not in room_response:
                return {
                    'success': False,
                    'error': f'Room {room_id} not found',
                    'access_granted': False
                }
            
            room = room_response['Item']
            required_access = room.get('RequiredAccessLevel', 'BASIC')
            
            # Check access level hierarchy
            access_hierarchy = {'BASIC': 0, 'STANDARD': 1, 'PREMIUM': 2, 'EXECUTIVE': 3}
            employee_level = access_hierarchy.get(access_level, 0)
            required_level = access_hierarchy.get(required_access, 0)
            
            access_granted = employee_level >= required_level
            
            return {
                'success': True,
                'access_granted': access_granted,
                'employee_id': employee_id,
                'employee_name': employee.get('Name', 'Unknown'),
                'access_level': access_level,
                'room_required_level': required_access,
                'room_name': room.get('RoomName', 'Unknown'),
                'error': None if access_granted else f'Insufficient access level. Required: {required_access}, Have: {access_level}'
            }
        except Exception as e:
            logger.error(f"Error verifying access: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'access_granted': False
            }
    
    @staticmethod
    def check_room_availability(room_id: str, start_time: str, end_time: str) -> Dict[str, Any]:
        """
        TOOL 2: Check if room is available for requested time slot
        Returns availability status and existing bookings
        """
        try:
            # Query existing bookings for the room
            response = BOOKINGS_TABLE.query(
            KeyConditionExpression='RoomID = :rid',
            FilterExpression='BookingStatus = :status',
            ExpressionAttributeValues={
            ':rid': room_id,
            ':status': 'CONFIRMED'
        }
    )
            
            
            existing_bookings = response.get('Items', [])
            
            # Parse requested times
            req_start = datetime.fromisoformat(start_time)
            req_end = datetime.fromisoformat(end_time)
            buffer_minutes = 15
            
            conflicts = []
            for booking in existing_bookings:
                booking_start = datetime.fromisoformat(booking['StartTime'])
                booking_end = datetime.fromisoformat(booking['EndTime'])
                
                # Check for overlap with buffer
                if not (req_end + timedelta(minutes=buffer_minutes) <= booking_start or 
                        req_start - timedelta(minutes=buffer_minutes) >= booking_end):
                    conflicts.append({
                        'booking_id': booking['BookingID'],
                        'meeting_title': booking.get('MeetingTitle', 'Unknown'),
                        'start_time': booking['StartTime'],
                        'end_time': booking['EndTime'],
                        'organizer': booking.get('EmployeeID', 'Unknown')
                    })
            
            available = len(conflicts) == 0
            
            return {
                'success': True,
                'room_id': room_id,
                'available': available,
                'requested_start': start_time,
                'requested_end': end_time,
                'conflicts': conflicts,
                'error': None if available else f'Room has {len(conflicts)} conflicting booking(s)'
            }
        except Exception as e:
            logger.error(f"Error checking availability: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'available': False
            }
    
    @staticmethod
    def calculate_meeting_duration(start_time: str, end_time: str, access_level: str) -> Dict[str, Any]:
        """
        TOOL 3: Calculate meeting duration and validate against access level limits
        """
        try:
            start = datetime.fromisoformat(start_time)
            end = datetime.fromisoformat(end_time)
            
            duration = end - start
            hours = int(duration.total_seconds() // 3600)
            minutes = int((duration.total_seconds() % 3600) // 60)
            
            # Access level limits (in hours)
            booking_limits = {
                'BASIC': 2,
                'STANDARD': 4,
                'PREMIUM': 8,
                'EXECUTIVE': 24
            }
            
            max_duration = booking_limits.get(access_level, 2)
            total_hours = duration.total_seconds() / 3600
            within_limit = total_hours <= max_duration
            
            return {
                'success': True,
                'duration_hours': hours,
                'duration_minutes': minutes,
                'total_duration_hours': round(total_hours, 2),
                'access_level': access_level,
                'max_allowed_hours': max_duration,
                'within_limit': within_limit,
                'error': None if within_limit else f'Duration exceeds limit of {max_duration} hours for {access_level} access'
            }
        except Exception as e:
            logger.error(f"Error calculating duration: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def get_room_details(room_id: str) -> Dict[str, Any]:
        """
        TOOL 4: Retrieve room details including capacity and features
        """
        try:
            room_response = ROOMS_TABLE.get_item(Key={'RoomID': room_id})
            if 'Item' not in room_response:
                return {
                    'success': False,
                    'error': f'Room {room_id} not found'
                }
            
            room = room_response['Item']
            
            # Get features
            features_response = ROOM_FEATURES_TABLE.query(
                KeyConditionExpression='RoomID = :rid',
                ExpressionAttributeValues={':rid': room_id}
            )
            features = [f['FeatureName'] for f in features_response.get('Items', [])]
            
            return {
                'success': True,
                'room_id': room_id,
                'room_name': room.get('RoomName', ''),
                'capacity': room.get('Capacity', 0),
                'location': room.get('Location', ''),
                'features': features,
                'required_access_level': room.get('RequiredAccessLevel', 'BASIC'),
                'floor': room.get('Floor', '')
            }
        except Exception as e:
            logger.error(f"Error getting room details: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def validate_attendee_count(room_id: str, attendee_count: int) -> Dict[str, Any]:
        """
        TOOL 5: Validate if room capacity is sufficient for attendee count
        """
        try:
            room_response = ROOMS_TABLE.get_item(Key={'RoomID': room_id})
            if 'Item' not in room_response:
                return {
                    'success': False,
                    'error': f'Room {room_id} not found'
                }
            
            room = room_response['Item']
            capacity = room.get('Capacity', 0)
            valid = attendee_count <= capacity
            
            return {
                'success': True,
                'room_id': room_id,
                'attendee_count': attendee_count,
                'room_capacity': capacity,
                'capacity_sufficient': valid,
                'error': None if valid else f'Attendee count ({attendee_count}) exceeds room capacity ({capacity})'
            }
        except Exception as e:
            logger.error(f"Error validating attendee count: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }
    
    @staticmethod
    def create_booking(booking_request: BookingRequest) -> Dict[str, Any]:
        """
        TOOL 6: Create booking record in DynamoDB (only after confirmation)
        """
        try:
            booking_id = str(uuid.uuid4())
            current_time = datetime.utcnow().isoformat()
            
            item = {
                'BookingID': booking_id,
                'RoomID': booking_request.room_id,
                'EmployeeID': booking_request.employee_id,
                'StartTime': booking_request.start_time,
                'EndTime': booking_request.end_time,
                'AttendeeCount': booking_request.attendee_count,
                'MeetingTitle': booking_request.meeting_title,
                'BookingStatus': 'CONFIRMED',
                'CreatedAt': current_time,
                'UpdatedAt': current_time
            }
            
            # Atomic write to bookings table
            BOOKINGS_TABLE.put_item(Item=item)
            
            logger.info(f"Booking created: {booking_id}")
            
            return {
                'success': True,
                'booking_id': booking_id,
                'status': 'CONFIRMED',
                'message': 'Booking successfully created and saved to database'
            }
        except Exception as e:
            logger.error(f"Error creating booking: {str(e)}")
            return {
                'success': False,
                'error': str(e)
            }


class BookingOrchestrator:
    """Orchestrates the booking workflow with sequential and parallel execution"""
    
    def __init__(self):
        self.tool_executor = ToolExecutor()
    
    async def execute_sequential(self, booking_request: BookingRequest) -> Dict[str, Any]:
        """
        Sequential execution: Each step is blocked on the previous one
        """
        logger.info("Starting SEQUENTIAL booking workflow")
        
        # Step 1: Verify employee access
        access_result = self.tool_executor.verify_employee_access(
            booking_request.employee_id,
            booking_request.room_id
        )
        if not access_result['success'] or not access_result['access_granted']:
            return {
                'workflow': 'sequential',
                'status': 'FAILED',
                'step': 'access_verification',
                'error': access_result.get('error', 'Access verification failed')
            }
        
        # Step 2: Check room availability
        availability_result = self.tool_executor.check_room_availability(
            booking_request.room_id,
            booking_request.start_time,
            booking_request.end_time
        )
        if not availability_result['success'] or not availability_result['available']:
            return {
                'workflow': 'sequential',
                'status': 'FAILED',
                'step': 'availability_check',
                'error': availability_result.get('error', 'Room not available'),
                'conflicts': availability_result.get('conflicts', [])
            }
        
        # Step 3: Calculate meeting duration
        duration_result = self.tool_executor.calculate_meeting_duration(
            booking_request.start_time,
            booking_request.end_time,
            access_result['access_level']
        )
        if not duration_result['success'] or not duration_result['within_limit']:
            return {
                'workflow': 'sequential',
                'status': 'FAILED',
                'step': 'duration_validation',
                'error': duration_result.get('error', 'Duration exceeds limit')
            }
        
        # Step 4: Validate attendee count
        attendee_result = self.tool_executor.validate_attendee_count(
            booking_request.room_id,
            booking_request.attendee_count
        )
        if not attendee_result['success'] or not attendee_result['capacity_sufficient']:
            return {
                'workflow': 'sequential',
                'status': 'FAILED',
                'step': 'capacity_validation',
                'error': attendee_result.get('error', 'Insufficient room capacity')
            }
        
        # Step 5: Human confirmation
        room_details = self.tool_executor.get_room_details(booking_request.room_id)
        
        confirmation_summary = {
            'room_name': room_details.get('room_name'),
            'capacity': room_details.get('capacity'),
            'features': room_details.get('features'),
            'start_time': booking_request.start_time,
            'end_time': booking_request.end_time,
            'duration_hours': duration_result['duration_hours'],
            'duration_minutes': duration_result['duration_minutes'],
            'attendee_count': booking_request.attendee_count,
            'meeting_title': booking_request.meeting_title
        }
        
        return {
            'workflow': 'sequential',
            'status': 'PENDING_CONFIRMATION',
            'booking_request': booking_request.__dict__,
            'confirmation_summary': confirmation_summary,
            'access_result': access_result,
            'availability_result': availability_result,
            'duration_result': duration_result,
            'attendee_result': attendee_result
        }
    
    async def execute_parallel(self, booking_request: BookingRequest) -> Dict[str, Any]:
        """
        Parallel execution: Access and availability checks run simultaneously
        """
        logger.info("Starting PARALLEL booking workflow")
        
        # Step 1 & 2: Run in parallel
        access_result = self.tool_executor.verify_employee_access(
            booking_request.employee_id,
            booking_request.room_id
        )
        availability_result = self.tool_executor.check_room_availability(
            booking_request.room_id,
            booking_request.start_time,
            booking_request.end_time
        )
        
        # Check both results
        if not access_result['success'] or not access_result['access_granted']:
            return {
                'workflow': 'parallel',
                'status': 'FAILED',
                'step': 'access_verification',
                'error': access_result.get('error', 'Access verification failed')
            }
        
        if not availability_result['success'] or not availability_result['available']:
            return {
                'workflow': 'parallel',
                'status': 'FAILED',
                'step': 'availability_check',
                'error': availability_result.get('error', 'Room not available')
            }
        
        # Step 3: Calculate meeting duration
        duration_result = self.tool_executor.calculate_meeting_duration(
            booking_request.start_time,
            booking_request.end_time,
            access_result['access_level']
        )
        if not duration_result['success'] or not duration_result['within_limit']:
            return {
                'workflow': 'parallel',
                'status': 'FAILED',
                'step': 'duration_validation',
                'error': duration_result.get('error', 'Duration exceeds limit')
            }
        
        # Step 4: Validate attendee count
        attendee_result = self.tool_executor.validate_attendee_count(
            booking_request.room_id,
            booking_request.attendee_count
        )
        if not attendee_result['success'] or not attendee_result['capacity_sufficient']:
            return {
                'workflow': 'parallel',
                'status': 'FAILED',
                'step': 'capacity_validation',
                'error': attendee_result.get('error', 'Insufficient room capacity')
            }
        
        # Step 5: Human confirmation
        room_details = self.tool_executor.get_room_details(booking_request.room_id)
        
        confirmation_summary = {
            'room_name': room_details.get('room_name'),
            'capacity': room_details.get('capacity'),
            'features': room_details.get('features'),
            'start_time': booking_request.start_time,
            'end_time': booking_request.end_time,
            'duration_hours': duration_result['duration_hours'],
            'duration_minutes': duration_result['duration_minutes'],
            'attendee_count': booking_request.attendee_count,
            'meeting_title': booking_request.meeting_title
        }
        
        return {
            'workflow': 'parallel',
            'status': 'PENDING_CONFIRMATION',
            'parallel_execution_note': 'Access and availability checks executed in parallel',
            'booking_request': booking_request.__dict__,
            'confirmation_summary': confirmation_summary,
            'access_result': access_result,
            'availability_result': availability_result,
            'duration_result': duration_result,
            'attendee_result': attendee_result
        }
    
    def confirm_booking(self, booking_request: BookingRequest, confirmed: bool) -> Dict[str, Any]:
        """
        Human-in-the-loop: Process confirmation response
        """
        if not confirmed:
            logger.info(f"Booking cancelled by user for room {booking_request.room_id}")
            return {
                'status': 'CANCELLED',
                'message': 'Booking cancelled by user',
                'database_record_created': False
            }
        
        # Create booking in database
        booking_result = self.tool_executor.create_booking(booking_request)
        
        if booking_result['success']:
            logger.info(f"Booking confirmed and saved: {booking_result['booking_id']}")
            return {
                'status': 'CONFIRMED',
                'booking_id': booking_result['booking_id'],
                'message': 'Booking successfully confirmed and saved to database',
                'database_record_created': True
            }
        else:
            return {
                'status': 'FAILED',
                'error': booking_result.get('error'),
                'database_record_created': False
            }


def lambda_handler(event, context):
    """
    AWS Lambda handler for the booking agent
    Expected event structure:
    {
        "action": "sequential|parallel|confirm",
        "employee_id": "E001",
        "room_id": "R001",
        "start_time": "2026-01-15T10:00:00",
        "end_time": "2026-01-15T12:00:00",
        "attendee_count": 5,
        "meeting_title": "Team Sync",
        "confirmed": true  # Only for confirm action
    }
    """
    try:
        action = event.get('action', 'sequential')
        
        booking_request = BookingRequest(
            employee_id=event['employee_id'],
            room_id=event['room_id'],
            start_time=event['start_time'],
            end_time=event['end_time'],
            attendee_count=event['attendee_count'],
            meeting_title=event['meeting_title']
        )
        
        orchestrator = BookingOrchestrator()
        
        if action == 'sequential':
            result = orchestrator.execute_sequential(booking_request)
        elif action == 'parallel':
            result = orchestrator.execute_parallel(booking_request)
        elif action == 'confirm':
            confirmed = event.get('confirmed', False)
            result = orchestrator.confirm_booking(booking_request, confirmed)
        else:
            result = {'error': f'Unknown action: {action}'}
        
        return {
            'statusCode': 200,
            'body': json.dumps(result, default=str)
        }
    
    except Exception as e:
        logger.error(f"Lambda handler error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }