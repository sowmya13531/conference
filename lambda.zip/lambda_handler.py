"""
AWS Lambda Handler for Conference Room Booking Agent
Deployed to AWS Lambda for Bedrock AgentCore integration
"""

import json
import logging
import boto3
import asyncio
from datetime import datetime
from typing import Any, Dict

# Import booking orchestrator
from booking_agent import BookingOrchestrator, BookingRequest

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def format_response(status_code: int, body: Dict[str, Any]) -> Dict:
    """Format Lambda response"""
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(body, default=str, indent=2)
    }


def validate_booking_request(event: Dict) -> tuple[bool, str]:
    """Validate incoming booking request"""
    required_fields = [
        'employee_id',
        'room_id',
        'start_time',
        'end_time',
        'attendee_count',
        'meeting_title'
    ]
    
    for field in required_fields:
        if field not in event:
            return False, f"Missing required field: {field}"
    
    # Validate attendee count is positive
    if not isinstance(event['attendee_count'], int) or event['attendee_count'] <= 0:
        return False, "attendee_count must be a positive integer"
    
    # Validate times are valid ISO format
    try:
        datetime.fromisoformat(event['start_time'])
        datetime.fromisoformat(event['end_time'])
    except ValueError:
        return False, "start_time and end_time must be in ISO 8601 format"
    
    # Validate start time is before end time
    if event['start_time'] >= event['end_time']:
        return False, "start_time must be before end_time"
    
    return True, ""


def handler(event, context):
    """
    Main Lambda handler for booking requests
    
    Event format:
    {
        "action": "sequential|parallel|confirm",
        "employee_id": "E001",
        "room_id": "R001",
        "start_time": "2026-01-15T10:00:00",
        "end_time": "2026-01-15T12:00:00",
        "attendee_count": 5,
        "meeting_title": "Team Sync",
        "confirmed": true  # Only for confirm action
    }
    """
    
    logger.info(f"Received event: {json.dumps(event)}")
    
    try:
        # Parse action
        action = event.get('action', 'sequential').lower()
        
        # Validate action
        if action not in ['sequential', 'parallel', 'confirm']:
            return format_response(400, {
                'error': f'Invalid action: {action}. Must be sequential, parallel, or confirm.'
            })
        
        # Validate booking request fields
        is_valid, error_msg = validate_booking_request(event)
        if not is_valid:
            return format_response(400, {
                'error': error_msg
            })
        
        # Create booking request object
        booking_request = BookingRequest(
            employee_id=event['employee_id'],
            room_id=event['room_id'],
            start_time=event['start_time'],
            end_time=event['end_time'],
            attendee_count=event['attendee_count'],
            meeting_title=event['meeting_title']
        )
        
        # Initialize orchestrator
        orchestrator = BookingOrchestrator()
        
        # Execute appropriate action
        if action == "sequential":
            logger.info(
                f"Executing SEQUENTIAL booking for employee {booking_request.employee_id}"
            )

            result = asyncio.run(
                orchestrator.execute_sequential(booking_request)
            )

        elif action == "parallel":
            logger.info(
                f"Executing PARALLEL booking for employee {booking_request.employee_id}"
            )

            result = asyncio.run(
                orchestrator.execute_parallel(booking_request)
            )

        elif action == "confirm":
            logger.info("Processing confirmation for booking")

            confirmed = event.get("confirmed", False)

            if not isinstance(confirmed, bool):
                return format_response(
                    400,
                    {
                        "error": "confirmed field must be a boolean (true/false)"
                    }
                )

            result = orchestrator.confirm_booking(
                booking_request,
                confirmed
            )
        
        # Return successful response
        return format_response(200, {
            'success': True,
            'action': action,
            'timestamp': datetime.utcnow().isoformat(),
            'result': result
        })
    
    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {str(e)}")
        return format_response(400, {
            'error': f'Invalid JSON in request body: {str(e)}'
        })
    
    except KeyError as e:
        logger.error(f"Missing required field: {str(e)}")
        return format_response(400, {
            'error': f'Missing required field: {str(e)}'
        })
    
    except Exception as e:
        logger.error(f"Unexpected error: {str(e)}", exc_info=True)
        return format_response(500, {
            'error': f'Internal server error: {str(e)}',
            'type': type(e).__name__
        })


def handle_bedrock_agent_input(event: Dict) -> Dict:
    """
    Specialized handler for Bedrock Agent tool invocations
    Converts Bedrock tool format to booking_agent format
    """
    
    try:
        # Extract tool invocation details
        tool_use = event.get('tool_use', {})
        tool_name = tool_use.get('name')
        tool_input = tool_use.get('input', {})
        
        logger.info(f"Bedrock Agent invoking tool: {tool_name}")
        
        # Route to appropriate tool executor
        from booking_agent import ToolExecutor
        
        executor = ToolExecutor()
        result = None
        
        if tool_name == 'verify_employee_access':
            result = executor.verify_employee_access(
                tool_input.get('employee_id'),
                tool_input.get('room_id')
            )
        
        elif tool_name == 'check_room_availability':
            result = executor.check_room_availability(
                tool_input.get('room_id'),
                tool_input.get('start_time'),
                tool_input.get('end_time')
            )
        
        elif tool_name == 'calculate_meeting_duration':
            result = executor.calculate_meeting_duration(
                tool_input.get('start_time'),
                tool_input.get('end_time'),
                tool_input.get('access_level')
            )
        
        elif tool_name == 'get_room_details':
            result = executor.get_room_details(tool_input.get('room_id'))
        
        elif tool_name == 'validate_attendee_count':
            result = executor.validate_attendee_count(
                tool_input.get('room_id'),
                tool_input.get('attendee_count')
            )
        
        elif tool_name == 'create_booking':
            booking_req = BookingRequest(
                employee_id=tool_input.get('employee_id'),
                room_id=tool_input.get('room_id'),
                start_time=tool_input.get('start_time'),
                end_time=tool_input.get('end_time'),
                attendee_count=tool_input.get('attendee_count'),
                meeting_title=tool_input.get('meeting_title')
            )
            result = executor.create_booking(booking_req)
        
        else:
            result = {
                'success': False,
                'error': f'Unknown tool: {tool_name}'
            }
        
        return {
            'statusCode': 200,
            'tool': tool_name,
            'result': result,
            'timestamp': datetime.utcnow().isoformat()
        }
    
    except Exception as e:
        logger.error(f"Error handling Bedrock tool invocation: {str(e)}", exc_info=True)
        return {
            'statusCode': 500,
            'error': str(e),
            'timestamp': datetime.utcnow().isoformat()
        }


# Export handlers
__all__ = ['handler', 'handle_bedrock_agent_input', 'format_response']